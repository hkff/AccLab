dhx4.ajax.xpath= function(xpathExp, docObj) {
	if (!docObj.nodeName)
		docObj = docObj.responseXML || docObj;

	if (dhx4.isIE){
		return docObj.selectNodes(xpathExp)||[];
	}else {
		var rows = [], first;
		var col = (docObj.ownerDocument||docObj).evaluate(xpathExp, docObj, null, XPathResult.ANY_TYPE, null);
		while (first = col.iterateNext())
			rows.push(first);
		return rows;
	}
};

dhx4.ajax.parse = function(data) {
	data = data.replace(/^[\s]+/,"");
	if (window.DOMParser && !dhx4.isIE) { // ff,ie9
		var obj = (new window.DOMParser()).parseFromString(data, "text/xml");
	} else if (window.ActiveXObject !== window.undefined) {
		var obj = new window.ActiveXObject("Microsoft.XMLDOM");
		obj.async = "false";
		obj.loadXML(data);
	}
	return obj;
};